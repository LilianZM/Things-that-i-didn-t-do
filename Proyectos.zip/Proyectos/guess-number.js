let targetNumber;
let attempts = 0;
const maxAttempts = 10;

const numberInput = document.getElementById('number-input');
const checkButton = document.getElementById('check-button');
const messageElement = document.getElementById('message');
const attemptsElement = document.getElementById('attempts');
const resetButton = document.getElementById('reset-button');

function initGame() {
    targetNumber = Math.floor(Math.random() * 100) + 1;
    attempts = 0;
    attemptsElement.textContent = attempts;
    messageElement.textContent = '';
    messageElement.className = '';
    resetButton.style.display = 'none';
    numberInput.value = '';
    numberInput.disabled = false;
    checkButton.disabled = false;
}

function checkNumber() {
    const userGuess = parseInt(numberInput.value);
    
    if (isNaN(userGuess) || userGuess < 1 || userGuess > 100) {
        messageElement.textContent = 'Por favor, ingresa un número válido entre 1 y 100';
        messageElement.className = 'message error';
        return;
    }

    attempts++;
    attemptsElement.textContent = attempts;

    if (userGuess === targetNumber) {
        messageElement.textContent = `¡Felicidades! Adivinaste el número en ${attempts} intentos 🎉`;
        messageElement.className = 'message success';
        numberInput.disabled = true;
        checkButton.disabled = true;
        resetButton.style.display = 'block';
    } else if (attempts >= maxAttempts) {
        messageElement.textContent = `¡Game Over! El número era ${targetNumber} 😢`;
        messageElement.className = 'message error';
        numberInput.disabled = true;
        checkButton.disabled = true;
        resetButton.style.display = 'block';
    } else {
        messageElement.textContent = userGuess > targetNumber ? 'El número es menor ⬇️' : 'El número es mayor ⬆️';
        messageElement.className = 'message';
    }
}

checkButton.addEventListener('click', checkNumber);
resetButton.addEventListener('click', initGame);
numberInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        checkNumber();
    }
});

// Iniciar el juego
initGame(); 